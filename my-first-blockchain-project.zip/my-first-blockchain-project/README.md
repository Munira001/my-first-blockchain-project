# My First Blockchain Project

This is my very first project on GitHub as I start learning blockchain development. 🚀

## Goals
- Learn Solidity basics
- Explore smart contracts
- Practice using GitHub
